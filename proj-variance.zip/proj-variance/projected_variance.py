import math


def projected_variance(X, direction):
    """
    Vrne varianco projekcij podatkov X na dano smer.

    Podatki v X so centrirani. Smerni vektor direction ni nujno enotski.
    """
    # TODO: normirajte smerni vektor na enotsko dolžino
    # TODO: izračunajte projekcije vseh točk in vrnite povprečje njihovih kvadratov
    pass


if __name__ == "__main__":
    # Preprost primer za ročno testiranje
    X = [(2.0, 0.0), (-2.0, 0.0), (0.0, 1.0), (0.0, -1.0)]
    result = projected_variance(X, (-1.0, 1.0))
    print(round(result, 4))
